import json,math,csv,re
from pathlib import Path
OUT=Path(__file__).resolve().parent
FP=json.loads((OUT/'source-footprints.json').read_text())
items=[];components=[]
def feature(id,ref,kind,x,y,w,h=None,**kw):
 d=dict(id=id,ref=ref,kind=kind,x=round(x,7),y=round(y,7),width=round(w,7),height=round(h if h is not None else w,7),rotation_deg=0,layer='PCB',**kw);items.append(d);return d
def component(ref,name,x,y,fp=None,angle=0,center=[0,0],mirror=False):
 components.append(dict(ref=ref,name=name,x=x,y=y,rotation_deg=angle,footprint=fp,layer='B.Cu' if mirror else 'F.Cu',centering_xy=center))
 if not fp:return
 for i,p in enumerate(FP[fp]['pads']):
  px=p['at3d'][0]-center[0];py=p['at3d'][1]-center[1]
  if mirror:px=-px
  t=math.radians(angle);ax=x+px*math.cos(t)-py*math.sin(t);ay=y+px*math.sin(t)+py*math.cos(t)
  ang=((p.get('rotation3dDeg',0)*(-1 if mirror else 1))+angle)%360
  ds=p.get('drill');is_mech=bool(ds and p['number']=='');src=f'Rev.D/{FP[fp]["source"]}'
  if not is_mech:
   q=feature(f'{ref}-pad-{i+1}',ref,'pad',ax,ay,*p['size'],pad_number=p['number'],pad_shape=p['shape'],pad_type=p['type'],copper_layer='B.Cu' if mirror else ('*.Cu' if ds else 'F.Cu'),source=src)
   q['rotation_deg']=ang
  if ds:
   q=feature(f'{ref}-drill-{i+1}',ref,'drill',ax,ay,*ds['size'],hole_shape=ds['shape'],plating='NPTH' if is_mech else 'PTH',pad_number=p['number'],source=src,classification_note='Source uses blank-number thru_hole; treated as mechanical NPTH in this proposal.' if is_mech else '')
   q['rotation_deg']=ang
keys=[(-20,10),(0,10),(-20,-10),(0,-10),(20,-10)]
for i,(x,y) in enumerate(keys):
 ref=f'SW{i+4}';component(ref,'SAMZO 28115181DM',x,y,'KEY-TH_28115181DM',center=[.63,-3.81])
 feature(f'RGB{i+1}-window',f'D{i+2}','window',x,y-5.2,3.4,3,corner_radius=.15,plating='none',source='Rev.D RGB footprint window + assembly proposal corner relief')
 component(f'D{i+2}','GL6028RGB01H-W reverse RGB',x,y-5.2,'LED_GL6028RGB01H-W_ReverseMount',mirror=True)
component('ENC1','EC11N1525404',20,10,'SW-TH_EC11NXXXX')
component('J1','GT-USB-7010ANS',0,22.2,'USB-C-SMD_GT-USB-7010ANS',angle=180)
# Top-mount tactiles: preserve source .kicad_mod pad positions exactly.
tactile='SW_GSwitch_GT-TC029B-H025-L1N'
for ref,x,name in [('SW2',-20,'RESET'),('SW3',-12,'BOOT')]:
 component(ref,name+' / GT-TC029B-H025-L1N',x,22,tactile)
 feature(ref+'-lid-access',ref,'access_hole',x,22,1.5,plating='none',source='Enclosure Print04: lid only; no PCB drill')['layer']='LID_ONLY'
# C963206 source EasyEDA footprint body-centered transform, rear-facing actuator.
s=json.loads((OUT/'source-C963206-package.json').read_text())
component('SW1','C963206 / MK-12C02-G020 body center',23,23.9)
for shape in s['shape']:
 a=shape.split('~')
 if a[0] not in ['PAD','HOLE']:continue
 rawx,rawy=float(a[2] if a[0]=='PAD' else a[1]),float(a[3] if a[0]=='PAD' else a[2])
 x=23-(rawx-4000.0005)*.254;y=23.9+(rawy-2999.409)*.254
 if a[0]=='PAD':
  q=feature('SW1-pad-'+a[8],'SW1','pad',x,y,float(a[4])*.254,float(a[5])*.254,pad_number=a[8],pad_shape='rect',pad_type='smd',copper_layer='F.Cu',source='LCSC / EasyEDA C963206 footprint; enlarged lands compared with vendor PDF')
  q['rotation_deg']=float(a[11])%360
 else:
  feature('SW1-locator-'+a[4],'SW1','drill',x,y,float(a[3])*2*.254,hole_shape='circle',plating='NPTH',pad_number='',source='LCSC / EasyEDA C963206 locator hole')
for i,(x,y) in enumerate([(-30,22),(30,22),(-30,-22),(30,-22)]):
 feature('H'+str(i+1),'H'+str(i+1),'drill',x,y,2.4,hole_shape='circle',plating='NPTH',pad_number='',source='Enclosure Print04 / M2 clearance mounting hole')
data=dict(format='CH592_PCB_MECHANICAL_PRINT04',units='mm',status='Structural placement proposal; not routed PCB, not released Gerber.',coordinate_system=dict(view='top',origin='board center',x_positive='right',y_positive='rear / USB edge',app_transform='app(x,y,z) = (X, pcb_height, -Y)',lower_left_bounding_box_transform='Xll=X+32.8; Yll=Y+25.8',plane='board plane before enclosure 6 degree tilt'),board=dict(width=65.6,height=51.6,thickness=1.6,corner_radius=3.6),components=components,features=items,notes=['All dimensions are millimetres; CSV preserves source decimal values.','Source blank-number drill-only thru_hole pads are classified as NPTH mechanical holes for this proposal; confirm in the final PCB.','RGB pads are source footprint placed on B.Cu, mirrored in X in top view. Confirm pin-1 and chain direction before routing.','C963206 lands follow LCSC/EasyEDA enlarged footprint, not the smaller copper lands drawn in manufacturer PDF.','LID_ONLY access holes must not be drilled in the PCB.','This is a mechanical placement reference only. No copper routing, net assignment, DRC or manufacturing release is supplied.'])
(OUT/'pcb-mechanical-data.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
fields=['id','ref','kind','layer','x','y','x_lower_left','y_lower_left','width','height','rotation_deg','pad_number','pad_shape','pad_type','copper_layer','hole_shape','plating','corner_radius','source','classification_note']
with open(OUT/'pcb-critical-coordinates.csv','w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fields,extrasaction='ignore');w.writeheader()
 for row in items:w.writerow(dict(row,x_lower_left=round(row['x']+32.8,7),y_lower_left=round(row['y']+25.8,7)))
with open(OUT/'component-centers.csv','w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,['ref','name','x','y','rotation_deg','layer','footprint'],extrasaction='ignore');w.writeheader();w.writerows(components)
print('Wrote',len(items),'features,',len(components),'components')
