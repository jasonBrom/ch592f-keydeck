"""Dimensional regression checks for the Print06 mechanical reference package."""
from pathlib import Path
import json,csv,math,hashlib
from pypdf import PdfReader
P=Path(__file__).resolve().parent
D=json.loads((P/'pcb-mechanical-data.json').read_text()); F=D['features']; B=D['board']; I=D['case_interfaces']
assert D['format']=='CH592_PCB_MECHANICAL_PRINT06'
assert len({f['id'] for f in F})==len(F)
rows=list(csv.DictReader((P/'pcb-critical-coordinates.csv').open(encoding='utf-8-sig')))
assert len(rows)==len(F)
for f,r in zip(F,rows):
 assert f['id']==r['id'] and f['layer']==r['layer']
 for k in ['x','y','width','height','rotation_deg']:assert abs(float(r[k])-f[k])<1e-8
for ref,(x,y) in zip(['SW4','SW5','SW6','SW7','SW8'],[(-20,10),(0,10),(-20,-10),(0,-10),(20,-10)]):
 fs=[f for f in F if f['ref']==ref and f['layer']=='PCB']; pads=[f for f in fs if f['kind']=='pad']; holes=[f for f in fs if f['kind']=='drill']
 assert len(pads)==2 and len(holes)==5
 assert all(f['copper_layer']=='B.Cu' and f['pad_type']=='smd' and (f['width'],f['height'])==(2.9,2.5) for f in pads)
 assert all(f['plating']=='NPTH' for f in holes)
 actual={(round(f['x']-x,5),round(f['y']-y,5),f['width']) for f in holes}
 assert actual=={(-3.81,2.54,3.0),(2.54,5.08,3.0),(0,0,4.0),(-5.08,0,2.0),(5.08,0,2.0)}
 for pad,(dx,dy) in zip(pads,[(-7.36,2.54),(6.09,5.08)]):assert abs(pad['x']-x-dx)<1e-6 and abs(pad['y']-y-dy)<1e-6
enc=[f for f in F if f['ref']=='ENC1' and f['kind']=='drill']
assert len(enc)==7 and not any(f['ref']=='ENC1' and f['kind']=='pad' for f in F)
assert {(f['pad_number'],round(f['x']-20,4),round(f['y']-10,4),f['width'],f['height'],f['plating']) for f in enc}=={('A',-2.5,-7.5,1.,1.,'PTH'),('C',0.,-7.5,1.,1.,'PTH'),('B',2.5,-7.5,1.,1.,'PTH'),('SW1',-2.5,7.,1.,1.,'PTH'),('SW2',2.5,7.,1.,1.,'PTH'),('SHIELD_LEFT',-5.7,0.,1.4,2.1,'UNSPECIFIED'),('SHIELD_RIGHT',5.7,0.,1.4,2.1,'UNSPECIFIED')}
# Rounded board bound: sample circle/slot envelopes including corner regions.
hw,hh,rad=B['width']/2,B['height']/2,B['corner_radius']
def in_board(x,y):
 if abs(x)>hw+1e-7 or abs(y)>hh+1e-7:return False
 return abs(x)<=hw-rad or abs(y)<=hh-rad or (abs(x)-(hw-rad))**2+(abs(y)-(hh-rad))**2<=rad*rad+1e-7
for f in F:
 if f['layer']!='PCB' or f['kind'] not in ['drill','window']:continue
 w,h=f['width'],f['height']
 if round(f['rotation_deg'])%180==90:w,h=h,w
 if w==h:
  points=[(f['x']+w/2*math.cos(t*math.pi/180),f['y']+h/2*math.sin(t*math.pi/180)) for t in range(360)]
 else:points=[(f['x']+dx*w/2,f['y']+dy*h/2) for dx in [-1,1] for dy in [-1,1]]
 assert all(in_board(x,y) for x,y in points),f['id']
plate=[f for f in F if f['kind']=='plate_opening']
assert len(plate)==5 and all(f['layer']=='CASE_ONLY' and f['width']==14.1 and f['corner_radius']==.15 for f in plate)
assert I['switch_plate']['seating_plane_app_y']==18.6 and I['switch_plate']['underside_app_y']==17.1
assert I['usb']['app_center']==[0,15.28,-28] and I['usb']['throat_width']==9.6 and I['usb']['throat_height']==3.8
for name in ['pcb-outline-and-holes.dxf','pcb-pad-reference.dxf','switch-retention-openings.dxf']:
 text=(P/name).read_text();assert '$INSUNITS\n70\n4\n' in text
 if name=='pcb-outline-and-holes.dxf':assert 'CASE' not in text and 'LID_' not in text and 'PAD' not in text
 if name=='pcb-pad-reference.dxf':assert 'B_CU_PAD' in text and 'DRILL' not in text
 if name=='switch-retention-openings.dxf':assert 'LID_RETENTION_OPENING' in text and 'PCB_' not in text
pdf=PdfReader(P/'CH592-PCB-Print06.pdf');assert len(pdf.pages)==5
for i,p in enumerate(pdf.pages):
 assert abs(float(p.mediabox.width)-297*72/25.4)<.01 and abs(float(p.mediabox.height)-210*72/25.4)<.01
 assert f'{i+1} / 5' in p.extract_text()
checks={'pdf_pages':5,'unique_features':len(F),'drills':sum(f['kind']=='drill' for f in F),'rgb_windows':sum(f['kind']=='window' for f in F),'case_only_openings':sum(f['layer']=='CASE_ONLY' for f in F),'hot_swap_b_cu_pads':10,'hot_swap_3mm_npth':10,'old_key_1_2mm_pth':0,'integral_retention_openings':5,'retention_corner_radius_mm':.15,'socket_b_cu_top_view_positions_verified':True,'all_hole_envelopes_within_board_bounds':True,'pcb_dxf_case_only_excluded':True,'csv_matches_json':True,'visual_review':'pending final page PNG inspection'}
files={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(P.iterdir()) if p.is_file() and p.name!='verification.json'}
(P/'verification.json').write_text(json.dumps({'files':files,'checks':checks},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(checks,ensure_ascii=False,indent=2))
