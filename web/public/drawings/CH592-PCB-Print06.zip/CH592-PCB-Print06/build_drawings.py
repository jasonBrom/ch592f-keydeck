from pathlib import Path
import math,json,html,zipfile
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor
from reportlab.lib.units import mm
OUT=Path(__file__).resolve().parent
D=json.loads((OUT/'pcb-mechanical-data.json').read_text());F=D['features'];C=D['components'];W,H=297,210
B=D['board'];I=D['case_interfaces'];S=D['source_packages']['socket'];E=D['source_packages']['encoder']
KEYREFS=['SW4','SW5','SW6','SW7','SW8'];PAGE_COUNT=5
pdfmetrics.registerFont(TTFont('DJV','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('DJVB','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
pdf=canvas.Canvas(str(OUT/'CH592-PCB-Print06.pdf'),pagesize=(W*mm,H*mm))
pdf.setTitle('CH592 Print06 - PCB mechanical reference')
pdf.setAuthor('CH592 Assembly Lab')
INK='#203a43';MUTED='#61777d';GRID='#d8e2e5';TEAL='#0c817a';BLUE='#2361b7';ORANGE='#b97518';PAPER='#ffffff';LIGHT='#f4f8f8'
class Page:
 def __init__(self,num,name,title,subtitle):
  self.svg=[];self.num=num;self.name=name
  self.rect(10,10,277,190,0,stroke=GRID,lw=.25)
  self.text(16,19,title,5.5,bold=True)
  self.text(16,26,subtitle,2.7,color=MUTED)
  self.line(16,31,281,31,GRID,.25)
  self.text(16,195,'PRINT06  |  mm  |  TOP VIEW: +X RIGHT / +Y REAR  |  STRUCTURAL PROPOSAL - NOT FOR PCB FABRICATION',2.25,color=MUTED)
  self.text(281,195,f'{num} / {PAGE_COUNT}',2.5,anchor='end',color=MUTED)
 def path(self,cmd,stroke=INK,fill='none',lw=.22,dash=None):
  # cmd [('M',x,y),('L',x,y),('C',x1,y1,x2,y2,x3,y3),('Z',)]
  p=pdf.beginPath();strings=[]
  for a in cmd:
   strings.append(a[0]+' '.join(f'{v:.5f}' for v in a[1:]))
   if a[0]=='M':p.moveTo(a[1]*mm,(H-a[2])*mm)
   elif a[0]=='L':p.lineTo(a[1]*mm,(H-a[2])*mm)
   elif a[0]=='C':p.curveTo(a[1]*mm,(H-a[2])*mm,a[3]*mm,(H-a[4])*mm,a[5]*mm,(H-a[6])*mm)
   elif a[0]=='Z':p.close()
  pdf.setLineWidth(lw*mm);pdf.setStrokeColor(HexColor(stroke if stroke!='none' else PAPER));pdf.setFillColor(HexColor(fill if fill!='none' else PAPER));pdf.setDash(dash or [])
  pdf.drawPath(p,stroke=int(stroke!='none'),fill=int(fill!='none'));pdf.setDash([])
  self.svg.append(f'<path d="{" ".join(strings)}" stroke="{stroke}" fill="{fill}" stroke-width="{lw}"'+(f' stroke-dasharray="{dash[0]},{dash[1]}"' if dash else '')+'/>')
 def line(self,x1,y1,x2,y2,color=INK,lw=.22,dash=None):self.path([('M',x1,y1),('L',x2,y2)],color,lw=lw,dash=dash)
 def rect(self,x,y,w,h,r=0,stroke=INK,fill='none',lw=.22,dash=None):
  if not r:self.path([('M',x,y),('L',x+w,y),('L',x+w,y+h),('L',x,y+h),('Z',)],stroke,fill,lw,dash);return
  r=min(r,w/2,h/2);k=.5522847498
  self.path([('M',x+r,y),('L',x+w-r,y),('C',x+w-r+k*r,y,x+w,y+r-k*r,x+w,y+r),('L',x+w,y+h-r),('C',x+w,y+h-r+k*r,x+w-r+k*r,y+h,x+w-r,y+h),('L',x+r,y+h),('C',x+r-k*r,y+h,x,y+h-r+k*r,x,y+h-r),('L',x,y+r),('C',x,y+r-k*r,x+r-k*r,y,x+r,y),('Z',)],stroke,fill,lw,dash)
 def circle(self,x,y,r,stroke=INK,fill='none',lw=.22,dash=None):self.rect(x-r,y-r,2*r,2*r,r,stroke,fill,lw,dash)
 def text(self,x,y,text,size=2.8,color=INK,bold=False,anchor='start'):
  pdf.setFillColor(HexColor(color));pdf.setFont('DJVB' if bold else 'DJV',size*mm)
  {'start':pdf.drawString,'middle':pdf.drawCentredString,'end':pdf.drawRightString}[anchor](x*mm,(H-y)*mm,text)
  self.svg.append(f'<text x="{x}" y="{y}" fill="{color}" font-family="DejaVu Sans,Arial,sans-serif" font-size="{size}"'+(' font-weight="700"' if bold else '')+f' text-anchor="{anchor}">{html.escape(text)}</text>')
 def arrow(self,x,y,dx,dy,color=INK):
  t=math.atan2(dy,dx);s=1.1
  self.path([('M',x,y),('L',x-s*math.cos(t)+s*.35*math.sin(t),y-s*math.sin(t)-s*.35*math.cos(t)),('L',x-s*math.cos(t)-s*.35*math.sin(t),y-s*math.sin(t)+s*.35*math.cos(t)),('Z',)],color,color,.1)
 def dimh(self,x1,x2,y,ext_y,label):
  for x in [x1,x2]:self.line(x,ext_y,x,y+1.2,GRID,.18)
  self.line(x1,y,x2,y,INK,.18);self.arrow(x1,y,-1,0);self.arrow(x2,y,1,0)
  self.rect((x1+x2)/2-len(label)*.85,y-3.3,len(label)*1.7,4,fill=PAPER,stroke='none')
  self.text((x1+x2)/2,y-.6,label,2.6,anchor='middle')
 def dimv(self,y1,y2,x,ext_x,label):
  for y in [y1,y2]:self.line(ext_x,y,x-1.2,y,GRID,.18)
  self.line(x,y1,x,y2,INK,.18);self.arrow(x,y1,0,-1);self.arrow(x,y2,0,1)
  self.rect(x-8,(y1+y2)/2-2,16,4,stroke='none',fill=PAPER)
  self.text(x,(y1+y2)/2+1,label,2.6,anchor='middle')
 def done(self):
  (OUT/(self.name+'.svg')).write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="297mm" height="210mm" viewBox="0 0 297 210"><rect width="297" height="210" fill="white"/>'+''.join(self.svg)+'</svg>')
  pdf.showPage()

def ft(page,feature,origin,scale,datum=(0,0)):
 x=origin[0]+(feature['x']-datum[0])*scale;y=origin[1]-(feature['y']-datum[1])*scale;w=feature['width']*scale;h=feature['height']*scale
 if int(round(feature['rotation_deg']))%180==90:w,h=h,w
 kind=feature['kind']
 if kind=='pad':
  r=min(w,h)/2 if feature.get('pad_shape') in ['circle','oval'] else min(w,h)*.18 if feature.get('pad_shape')=='roundrect' else 0
  page.rect(x-w/2,y-h/2,w,h,r,stroke='#815094' if feature.get('copper_layer')=='B.Cu' else '#b5c4c8',fill='#f2eafa' if feature.get('copper_layer')=='B.Cu' else '#e8eeee',lw=.12)
 elif kind=='drill':
  r=0 if feature.get('hole_shape')=='rect' else min(w,h)/2;col=BLUE if feature['plating']=='PTH' else ORANGE if feature['plating']=='UNSPECIFIED' else INK
  page.rect(x-w/2,y-h/2,w,h,r,stroke=col,fill=PAPER,lw=.22)
 elif kind=='plate_opening':page.rect(x-w/2,y-h/2,w,h,feature.get('corner_radius',0)*scale,stroke=ORANGE,fill='none',lw=.3)
 elif kind=='window':page.rect(x-w/2,y-h/2,w,h,feature.get('corner_radius',0)*scale,stroke=TEAL,fill='#e2f5ee',lw=.23)
 else:page.circle(x,y,w/2,stroke=ORANGE,lw=.3,dash=[.55,.4])

def drawref(page,refs,origin,scale,datum=(0,0)):
 fs=[f for f in F if f['ref'] in refs]
 for typ in ['pad','drill','window','access_hole']:
  for f in fs:
   if f['kind']==typ:ft(page,f,origin,scale,datum)

def cross(p,x,y,s=1.6,color=MUTED):p.line(x-s,y,x+s,y,color,.15);p.line(x,y-s,x,y+s,color,.15)
def table(p,x,y,width,headers,rows,colwidth=None,fs=2.7,rowh=6.2):
 if colwidth is None:colwidth=[width/len(headers)]*len(headers)
 p.rect(x,y,width,rowh,0,fill=LIGHT,stroke='none')
 for j,h in enumerate(headers):p.text(x+sum(colwidth[:j])+1.5,y+rowh*.7,h,fs,bold=True)
 for i,row in enumerate(rows):
  yy=y+(i+1)*rowh;p.line(x,yy+rowh,x+width,yy+rowh,GRID,.16)
  for j,txt in enumerate(row):p.text(x+sum(colwidth[:j])+1.5,yy+rowh*.69,str(txt),fs)

def subtitle(p,x,y,n,t):p.text(x,y,n,3.3,bold=True);p.text(x,y+5.3,t,2.5,color=MUTED)
def pair(p,x,y,a,b):p.text(x,y,a,2.55);p.text(x+60,y,b,2.55,anchor='end')

def p1():
 p=Page(1,'01-pcb-overview','CH592  /  PCB mechanical layout','Board 65.6 × 51.6 × 1.6   ·   R3.6 corners   ·   20 mm key pitch   ·   Print06 structural proposal')
 ox,oy,s=101,109,2.12;left=ox-32.8*s;right=ox+32.8*s;top=oy-25.8*s;bottom=oy+25.8*s
 p.rect(left,top,65.6*s,51.6*s,3.6*s,stroke=INK,fill='#fafcfc',lw=.4)
 p.line(left,oy,right,oy,GRID,.18,[1,.8]);p.line(ox,top,ox,bottom,GRID,.18,[1,.8])
 drawref(p,[c['ref'] for c in C]+['H1','H2','H3','H4'],(ox,oy),s)
 p.dimh(left,right,38,top,'65.60');p.dimh(ox-30*s,ox+30*s,46,oy-22*s,'60.00  mounting pitch')
 p.dimv(top,bottom,21,left,'51.60')
 for c in C:
  x=ox+c['x']*s;y=oy-c['y']*s
  if c['ref'] in ['SW4','SW5','SW6','SW7','SW8']:
   p.rect(x-8.6*s,y-8.6*s,17.2*s,17.2*s,1*s,stroke=GRID,lw=.2,dash=[1,.7])
   p.text(x,y-8.6*s+3.8,c['ref'],3.3,bold=True,anchor='middle');cross(p,x,y)
  elif c['ref']=='ENC1':
   p.circle(x,y,10*s,stroke=GRID,lw=.2,dash=[1,.7]);p.text(x,y-7,'ENC1',3.3,bold=True,anchor='middle');cross(p,x,y)
  elif c['ref'] in ['SW1','SW2','SW3','J1']:
   p.text(x,y-5.8,c['ref'],2.6,bold=True,anchor='middle')
 for i,(x,y) in enumerate([(-30,22),(30,22),(-30,-22),(30,-22)]):
  p.text(ox+x*s+(3 if x<0 else -3),oy-y*s+(5 if y>0 else -3),'H'+str(i+1),2.1,anchor='start' if x<0 else 'end',color=MUTED)
 cross(p,ox,oy,2);p.text(ox+3,oy+3.5,'O (0,0)',2.6)
 p.line(ox+2,oy,ox+10,oy,TEAL,.25);p.arrow(ox+10,oy,1,0,TEAL);p.text(ox+12,oy+1,'X',2.5,color=TEAL)
 p.line(ox,oy-1,ox,oy-5,TEAL,.25);p.arrow(ox,oy-5,0,-1,TEAL);p.text(ox+2,oy-4.5,'Y',2.5,color=TEAL)
 p.dimh(ox-20*s,ox,176,bottom,'20.00');p.dimh(ox,ox+20*s,176,bottom,'20.00')
 p.text(101,185,'FRONT / USER SIDE    ·    dashed = flange clearance / knob envelope',2.35,anchor='middle',color=MUTED)
 p.line(188,36,188,185,GRID,.25)
 p.text(195,41,'DATUM COORDINATES',3.0,bold=True)
 rows=[]
 for ref in ['SW4','SW5','SW6','SW7','SW8','ENC1','J1','SW1','SW2','SW3']:
  c=next(c for c in C if c['ref']==ref);rows.append((ref,f"{c['x']:+.2f}",f"{c['y']:+.2f}"))
 table(p,195,45,86,['Ref.','X','Y'],rows,[35,25,26],2.65,6)
 p.text(195,119,'H1 / H2: X = ±30, Y = +22',2.6)
 p.text(195,125,'H3 / H4: X = ±30, Y = -22',2.6)
 p.text(195,131,'4 × Ø2.40 NPTH for M2 screws',2.6,bold=True)
 p.circle(198,139,1.2,INK);p.text(202,140,'PCB mechanical / NPTH hole',2.45)
 p.circle(198,145,1.2,BLUE);p.text(202,146,'PCB signal / PTH hole or slot',2.45)
 p.rect(196.8,149.8,2.4,2.4,stroke='#815094',fill='#f2eafa');p.text(202,152,'B.Cu pad (top view; no extra mirror)',2.15)
 p.rect(196.5,156,3,2,stroke=TEAL,fill='#e2f5ee');p.text(202,158,'RGB through-board light window',2.45)
 p.rect(197.3,161.2,1.4,2.1,0,stroke=ORANGE);p.text(202,164,'ENC1 shell slots: plating TBD',2.35)
 p.text(195,170,'Board plane dimensions before 6° tilt.',2.45,color=MUTED)
 p.text(195,176,'Lower-left bounding-box origin:',2.45,color=MUTED)
 p.text(195,182,'Xll = X + 32.8;  Yll = Y + 25.8',2.55,bold=True)
 p.done()

def p2():
 p=Page(2,'02-switch-and-encoder','CH592  /  Hot-swap switch and encoder details','All geometry in PCB TOP VIEW. Purple lands are B.Cu. Switch and encoder datums are their stem / shaft axes.')
 subtitle(p,16,40,'A  SAMZO 28115181DM + C49352235','5 keys  ·  switch pattern shown once  ·  detail scale 5:1')
 ox,oy,s=68,94,5;drawref(p,['SW4','D2'],(ox,oy),s,(-20,10));cross(p,ox,oy,2)
 p.rect(ox-8.6*s,oy-8.6*s,17.2*s,17.2*s,s,stroke=GRID,dash=[1,.7])
 p.text(ox,oy+1,'O',2.5,anchor='middle')
 p.dimh(ox-5.08*s,ox+5.08*s,141,oy,'10.16 locator pitch')
 table(p,16,147,124,['Feature','Local X','Local Y','Size / type'],[
  ('Stem locator','0.00','0.00','Ø4.00 NPTH*'),('Side locators','±5.08','0.00','2 × Ø2.00 NPTH*'),('Socket pin 1','-3.81','+2.54','Ø3.00 NPTH'),('Socket pin 2','+2.54','+5.08','Ø3.00 NPTH'),('B.Cu pads','-7.36 / +6.09','+2.54 / +5.08','2.90 × 2.50')],[36,29,28,31],2.25,5.4)
 p.text(16,184,'* Existing-design clearances; verify SAMZO fit. No key Ø1.20 PTH remains.',2.18,color=ORANGE)
 p.line(147,36,147,185,GRID,.25)
 subtitle(p,154,40,'B  '+E['name']+' / ENC1','PROPOSED REPLACEMENT  ·  user hardware change not confirmed  ·  5:1')
 ox,oy,s=217,92,5;drawref(p,['ENC1'],(ox,oy),s,(20,10));cross(p,ox,oy,2)
 p.circle(ox,oy,I.get('encoder',{}).get('lid_shaft_bore',8.8)/2*s,stroke=GRID,dash=[1,.7]);p.text(ox,oy+1,'O',3,anchor='middle')
 for f in F:
  if f['ref']=='ENC1' and f['kind']=='drill':
   x=ox+(f['x']-20)*s;y=oy-(f['y']-10)*s
   shell=f.get('pad_number','').startswith('SHIELD') or f.get('pad_number') in ['EH','MP','S1','S2']
   p.text(x+(9 if f['x']>20 else -9) if shell else x,y+1 if shell else y+(-5 if f['y']>10 else 8),('SH-L' if f['x']<20 else 'SH-R') if shell else f.get('pad_number',''),2.6,anchor='middle')
 enc={f['pad_number']:f for f in F if f['ref']=='ENC1' and f['kind']=='drill'}
 fmt=lambda v:f'{v:+.2f}' if v else '0.00'
 rows=[
  ['A / C / B',' / '.join(fmt(enc[k]['x']-20) for k in ['A','C','B']),fmt(enc['A']['y']-10),f"Ø{enc['A']['width']:.2f} +0.20/-0"],
  ['SW1 / SW2',f"±{abs(enc['SW2']['x']-20):.2f}",fmt(enc['SW1']['y']-10),f"Ø{enc['SW1']['width']:.2f} +0.20/-0"],
  ['SH-L / SH-R',f"±{abs(enc['SHIELD_RIGHT']['x']-20):.2f}",fmt(enc['SHIELD_RIGHT']['y']-10),f"{enc['SHIELD_RIGHT']['width']:.2f} × {enc['SHIELD_RIGHT']['height']:.2f} slot"],
  ['Lid shaft bore','0.00','0.00',f"Ø{I['encoder']['lid_shaft_bore']:.2f} - lid only"]]
 table(p,154,140,127,['Feature','Local X','Local Y','Drill / cut'],rows,[31,40,23,33],2.2,5.4)
 p.text(154,171,'Ø6 / 18 teeth shaft; tip at PCB +19.50; body 4.50 + L15.',2.25,color=MUTED)
 p.text(154,178,'No copper annuli specified; shell-slot plating TBD by PCB design.',2.15,color=MUTED)
 p.text(154,184,'K-shaft LCSC availability unverified; order this exact suffix.',2.25,color=ORANGE)
 p.done()

def p3():
 p=Page(3,'03-usb-power-and-access','CH592  /  USB, power and side service access','PCB datums in X/Y. Sidewall opening centers use app (x,y,z), before the whole enclosure 6° rotation.')
 usb=D['case_interfaces']['usb'];tact=D['case_interfaces']['tactiles'];fix=D['case_interfaces']['fastening']
 subtitle(p,16,40,'C  USB-C / J1','GT-USB-7010ANS  ·  pad detail 5:1')
 ox,oy,s=58,86,5;drawref(p,['J1'],(ox,oy),s,(0,22.2));cross(p,ox,oy,2)
 p.line(20,oy-3.6*s,98,oy-3.6*s,TEAL,.4);p.text(58,63,'PCB REAR EDGE  Y = +25.80',2.3,anchor='middle',color=TEAL)
 for f in F:
  if f['ref']=='J1' and f['kind']=='drill' and f.get('pad_number'):
   x=ox+f['x']*s;y=oy-(f['y']-22.2)*s;p.text(x+(3 if x>ox else -3),y+1,f['pad_number'],2.2,anchor='start' if x>ox else 'end')
 table(p,16,112,86,['PCB feature','Local XY / drill'],[
 ('Shell 1 / 2','±4.32,-1.80 / 0.60×1.70'),('Shell 3 / 4','±4.32,+2.38 / 0.60×1.40'),('Locators','±2.89,-1.30 / Ø0.65'),('Origin / angle','(0,+22.20) / 180°')],[30,56],2.15,6)
 p.text(16,149,'CASE OPENING (not PCB cut)',2.7,bold=True)
 p.text(16,155,f"Throat {usb['throat_width']:.2f} × {usb['throat_height']:.2f}, R{usb['throat_radius']:.2f}",2.55)
 p.text(16,161,f"Outer mouth {usb['mouth_width']:.2f} × {usb['mouth_height']:.2f}",2.55)
 p.text(16,167,'3D center: '+', '.join(f'{v:g}' for v in usb['app_center']),2.45)
 p.text(16,173,f"Outer entry chamfer C{usb['mouth_chamfer']:.2f}.",2.3,color=MUTED)
 p.text(16,180,'Copper nearest rear edge: 0.32 mm nominal.',2.2,color=MUTED)
 p.line(106,36,106,185,GRID,.25)
 subtitle(p,112,40,'D  POWER / SW1','C963206  ·  MK-12C02-G020  ·  5:1')
 ox,oy,s=154,86,5;drawref(p,['SW1'],(ox,oy),s,(23,23.9));p.rect(ox-3.3*s,oy-1.35*s,6.6*s,2.7*s,stroke=GRID,dash=[1,.7]);cross(p,ox,oy,2)
 p.line(116,oy-1.9*s,193,oy-1.9*s,TEAL,.4)
 p.rect(ox-.65*s,oy-3.35*s,1.3*s,2*s,stroke=ORANGE,lw=.25);p.text(ox,63,'SLIDE ACTUATOR / REAR',2.4,anchor='middle',color=MUTED)
 for f in F:
  if f['ref']=='SW1' and f['kind']=='pad':
   x=ox+(f['x']-23)*s;y=oy-(f['y']-23.9)*s;p.text(x,y+(f['height']*s/2)+3,f['pad_number'],2.3,anchor='middle')
 table(p,112,112,84,['Item','mm'],[
 ('Body center','(+23,+23.90)'),('Body / travel','6.60×2.70×1.40 / 1.50'),('2 locator holes','Ø0.85 at X = ±1.50'),('Signal lands','0.90×2.00'),('Anchor lands','1.10×0.93')],[33,51],2.2,6)
 p.text(112,155,'LCSC / EasyEDA enlarged copper lands.',2.35,color=MUTED)
 p.text(112,161,'Body center differs from library header origin.',2.2,color=MUTED)
 p.text(112,173,'M2 SELF-TAPPING FASTENERS',2.55,bold=True)
 p.text(112,179,f"Lid pilot Ø{fix['pilot_diameter']:.2f}, depth {fix['pilot_depth']:.2f}.",2.4)
 p.line(201,36,201,185,GRID,.25)
 subtitle(p,207,40,'E  RESET / BOOT','C2762970  ·  side-actuated  ·  5:1')
 c=next(c for c in C if c['ref']=='SW2');ox,oy,s=244,86,5
 drawref(p,['SW2'],(ox,oy),s,(c['x'],c['y']));cross(p,ox,oy,2)
 for f in F:
  if f['ref']=='SW2' and f['kind']=='pad':
   x=ox+(f['x']-c['x'])*s;y=oy-(f['y']-c['y'])*s
   p.text(x+(4 if f['pad_number'] in ['1','2'] else -4),y+.8,f['pad_number'],2.1,anchor='start' if f['pad_number'] in ['1','2'] else 'end')
 p.text(ox,101,'Origin: midpoint of 2 locating posts',2.1,anchor='middle',color=MUTED)
 p.line(ox-tact['body_depth']/2*s,oy,213,oy,ORANGE,.3);p.arrow(213,oy,-1,0,ORANGE)
 p.text(ox,59,'ACTUATOR / LEFT',2.3,anchor='middle',color=ORANGE)
 rows=[]
 for ref in ['SW2','SW3']:
  c=next(c for c in C if c['ref']==ref);rows.append((ref,f"({c['x']:+.2f},{c['y']:+.2f})"))
 rows += [('Envelope',f"{tact['body_width']:g}×{tact['body_depth']:g}×{tact['body_height']:g}"),('2 locator holes',f"Ø{tact['locator_hole_diameter']:.2f} NPTH (proposal)")]
 table(p,207,112,74,['Item','mm'],rows,[29,45],2.15,6)
 p.text(207,149,'LEFT WALL ACCESS (2 ports)',2.5,bold=True)
 p.text(207,155,f"Each Ø{tact['access_diameter']:.2f}; axis app +X.",2.35)
 p.text(207,161,'Opening centers app (x,y,z):',2.3,color=MUTED)
 for i,center in enumerate(tact['access_centers']):p.text(207,167+i*6,', '.join(f'{v:g}' for v in center),2.45)
 p.text(207,180,'Pad size / holes: proposal; verify footprint.',2.25,color=ORANGE)
 p.done()

def p4():
 p=Page(4,'04-pcb-one-to-one','CH592  /  1:1 alignment reference','Print at Actual size / 100%. Disable Fit to page. Check the 50 mm scale bar before comparing against hardware.')
 ox,oy,s=76,93,1
 p.rect(ox-32.8,oy-25.8,65.6,51.6,3.6,stroke=INK,lw=.2)
 drawref(p,[c['ref'] for c in C]+['H1','H2','H3','H4'],(ox,oy),s)
 p.line(ox-35,oy,ox+35,oy,GRID,.12,[1,.8]);p.line(ox,oy-29,ox,oy+29,GRID,.12,[1,.8])
 p.dimh(ox-32.8,ox+32.8,53,oy-25.8,'65.60');p.dimv(oy-25.8,oy+25.8,31,ox-32.8,'51.60')
 p.text(76,128,'FRONT / USER',2.5,anchor='middle',color=MUTED)
 p.line(51,143,101,143,INK,.4)
 for x in [51,61,71,81,91,101]:p.line(x,141.5,x,144.5,INK,.25)
 p.text(76,151,'50.00 mm calibration',2.8,anchor='middle')
 p.text(16,165,'This page is an alignment template, not a drill program.',2.7,bold=True)
 p.text(16,172,'Sidewall access is excluded from this PCB template.',2.6,color=ORANGE)
 p.text(16,179,'M2 mounting holes: Ø2.40, non-plated.',2.7)
 p.line(140,38,140,184,GRID,.25)
 p.text(151,43,'RELEASE NOTES',3.4,bold=True)
 notes=[('01  Datums','All coordinates are in the PCB plane.','X increases right; Y increases toward USB.','App transform: appx = X, appz = -Y.'),('02  Hot-swap pattern','C49352235: 2 × Ø3.00 NPTH per switch.','Two 2.90 × 2.50 B.Cu lands per socket.','SAMZO stem locator clearances need sample fit.'),('03  RGB / service access','D2-D6 are on B.Cu, mirrored in X in top view.','Confirm pin 1 and chain direction before routing.','SW2 / SW3 access ports are in the left sidewall.'),('04  Enclosure and PCB release','M2 self-tappers engage resin pilot holes in the lid.','PCB holes remain Ø2.40 NPTH clearance holes.','ENC1 Bourns replacement is proposed, not confirmed.')]
 for i,(title,*lines) in enumerate(notes):
  y=55+i*28;p.text(151,y,title,2.9,bold=True)
  for j,line in enumerate(lines):p.text(151,y+6+j*5,line,2.55,color=MUTED)
 p.text(151,173,'Files: 5 SVG sheets, PDF, coordinates CSV,',2.55)
 p.text(151,179,'PCB / retention DXF, JSON and Chinese notes.',2.55)
 p.done()
def p5():
 p=Page(5,'05-switch-retention','CH592  /  Switch retention and socket stack','Integral lid ledges retain the switch clips. All dimensions are local, before enclosure tilt; plate features are CASE_ONLY.')
 q=I['switch_plate']; ox,oy,s=82,98,2.0
 subtitle(p,16,40,'F  SWITCH LOCATING OPENINGS','Top view 2:1  ·  centers shared with PCB  ·  orange = retaining aperture')
 for c in [c for c in C if c['ref'] in KEYREFS]:
  x=ox+c['x']*s;y=oy-c['y']*s
  p.rect(x-q['flange_clearance_width']/2*s,y-q['flange_clearance_height']/2*s,q['flange_clearance_width']*s,q['flange_clearance_height']*s,q['flange_clearance_radius']*s,stroke=GRID,dash=[1,.7])
  p.rect(x-q['opening_width']/2*s,y-q['opening_height']/2*s,q['opening_width']*s,q['opening_height']*s,q['opening_corner_radius']*s,stroke=ORANGE,lw=.35)
  cross(p,x,y,1);p.text(x,y-3,c['ref'],2.8,bold=True,anchor='middle')
 p.dimh(ox-20*s,ox,153,oy+10*s,'20.00');p.dimh(ox,ox+20*s,153,oy+10*s,'20.00')
 p.text(16,167,f"5 × {q['opening_width']:.2f} × {q['opening_height']:.2f}, R{q['opening_corner_radius']:.2f}",3,bold=True)
 p.text(16,174,'Dashed flange clearance: 17.20 × 17.20, R1.00.',2.6,color=MUTED)
 p.text(16,181,'Fit coupons: 14.00 / 14.10 / 14.20 square openings.',2.5,color=MUTED)
 p.line(162,36,162,185,GRID,.25)
 subtitle(p,169,40,'G  LOCAL VERTICAL STACK','Section through switch center  ·  5:1  ·  app Y heights in mm')
 # One half section keeps annotation leaders clear; the other is symmetric.
 ox,oy,s=220,128,5; by=lambda v: oy-(v-12)*s
 p.rect(174,by(13.6),85,1.6*s,stroke=INK,fill='#e8eeee',lw=.3)
 p.text(264,by(13.6)+2,'13.60',2.6);p.text(264,by(12)+2,'12.00',2.6)
 for sign in [-1,1]:
  x=ox+sign*q['opening_width']/2*s
  if sign<0:x-=7
  p.rect(x,by(q['seating_plane_app_y']),7,q['effective_thickness']*s,stroke=ORANGE,fill='#fff0d9',lw=.3)
 p.line(174,by(q['seating_plane_app_y']),259,by(q['seating_plane_app_y']),GRID,.2,[.8,.6])
 p.text(264,by(q['seating_plane_app_y'])+2,'18.60',2.6)
 p.text(264,by(q['underside_app_y'])+2,'17.10',2.6)
 socket_depth=S['mount']['conservative_metal_envelope_below_pcb_bottom_mm']
 p.rect(ox-5.45*s,by(12),10.9*s,socket_depth*s,stroke='#815094',fill='#f2eafa',lw=.3)
 p.text(ox,by(12)+socket_depth*s+5,'C49352235 / PCB B side',2.5,anchor='middle',color='#815094')
 p.dimh(ox-q['opening_width']/2*s,ox+q['opening_width']/2*s,62,by(q['seating_plane_app_y']),f"{q['opening_width']:.2f}")
 p.text(169,157,'Retention seat: PCB top + 5.00 = app 18.60.',2.6,bold=True)
 p.text(169,164,'Effective ledge thickness: 1.50 mm.',2.6)
 p.text(169,171,'Socket metal: 1.85 ±0.10; use 1.95 below PCB.',2.45,color=MUTED)
 p.text(169,178,'3.05 total socket height includes PCB insertion.',2.35,color=MUTED)
 p.done()
p1();p2();p3();p4();p5();pdf.save()

# True metric DXF, PCB-only geometry: outline, drill circles/slots and RGB windows.
entities=[]
def emit(*pairs):
 for a,b in zip(pairs[::2],pairs[1::2]):entities.extend([str(a),str(b)])
def line(x1,y1,x2,y2,layer):emit(0,'LINE',8,layer,10,x1,20,y1,30,0,11,x2,21,y2,31,0)
def circle(x,y,r,layer):emit(0,'CIRCLE',8,layer,10,x,20,y,30,0,40,r)
def arc(x,y,r,a,b,layer):emit(0,'ARC',8,layer,10,x,20,y,30,0,40,r,50,a,51,b)
def rounded(x,y,w,h,r,layer):
 l=x-w/2;rr=x+w/2;b=y-h/2;t=y+h/2
 line(l+r,b,rr-r,b,layer);line(rr,b+r,rr,t-r,layer);line(rr-r,t,l+r,t,layer);line(l,t-r,l,b+r,layer)
 if not r:return
 arc(rr-r,b+r,r,270,360,layer);arc(rr-r,t-r,r,0,90,layer);arc(l+r,t-r,r,90,180,layer);arc(l+r,b+r,r,180,270,layer)
rounded(0,0,B['width'],B['height'],B['corner_radius'],'PCB_OUTLINE')
for f in F:
 if f['layer']!='PCB' or f['kind'] not in ['drill','window']:continue
 x,y,w,h=f['x'],f['y'],f['width'],f['height']
 if int(round(f['rotation_deg']))%180==90:w,h=h,w
 layer='RGB_WINDOW' if f['kind']=='window' else ('DRILL_PTH' if f['plating']=='PTH' else 'DRILL_PLATING_TBD' if f['plating']=='UNSPECIFIED' else 'DRILL_NPTH')
 if abs(w-h)<1e-8 and f['kind']=='drill':circle(x,y,w/2,layer)
 else:rounded(x,y,w,h,f.get('corner_radius',0 if f.get('hole_shape')=='rect' else min(w,h)/2),layer)
head=['0','SECTION','2','HEADER','9','$ACADVER','1','AC1015','9','$INSUNITS','70','4','0','ENDSEC','0','SECTION','2','ENTITIES']
(OUT/'pcb-outline-and-holes.dxf').write_text('\n'.join(head+entities+['0','ENDSEC','0','EOF'])+'\n')
# Separate plate-only file: never mix lid retention cuts with PCB drill geometry.
entities=[]
for f in F:
 if f['kind']=='plate_opening':rounded(f['x'],f['y'],f['width'],f['height'],f['corner_radius'],'LID_RETENTION_OPENING')
(OUT/'switch-retention-openings.dxf').write_text('\n'.join(head+entities+['0','ENDSEC','0','EOF'])+'\n')
entities=[]
for f in F:
 if f['layer']!='PCB' or f['kind']!='pad':continue
 x,y,w,h=f['x'],f['y'],f['width'],f['height']
 if int(round(f['rotation_deg']))%180==90:w,h=h,w
 layer='B_CU_PAD' if f.get('copper_layer')=='B.Cu' else 'THROUGH_PAD' if f.get('pad_type')=='thru_hole' else 'F_CU_PAD'
 r=min(w,h)/2 if f.get('pad_shape') in ['circle','oval'] else min(w,h)*.18 if f.get('pad_shape')=='roundrect' else 0
 if f.get('pad_shape')=='circle' and abs(w-h)<1e-8:circle(x,y,w/2,layer)
 elif r:rounded(x,y,w,h,r,layer)
 else:
  line(x-w/2,y-h/2,x+w/2,y-h/2,layer);line(x+w/2,y-h/2,x+w/2,y+h/2,layer);line(x+w/2,y+h/2,x-w/2,y+h/2,layer);line(x-w/2,y+h/2,x-w/2,y-h/2,layer)
(OUT/'pcb-pad-reference.dxf').write_text('\n'.join(head+entities+['0','ENDSEC','0','EOF'])+'\n')
print('Created 5 SVGs, 5-page PDF, metric PCB DXF and separate lid-retention DXF')
