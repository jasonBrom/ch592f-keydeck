"""CH592 v4 first-fit enclosure. Units mm. Python 3 + cadquery + trimesh.
CAD x = app x; CAD y = -app z; CAD z = app y.
Outputs exact STEP solids, outward STL in print orientation, browser geometry,
and a geometric validation report. This is a first-fit concept, not production CAD.
"""
from pathlib import Path
import math, json, sys, zipfile
import numpy as np
import cadquery as cq
import trimesh

OUT = Path(__file__).resolve().parent
P = dict(width=70., depth=56., outline_radius=6., tilt_deg=6., wall=2., floor=2.,
         top_bottom=17.6, top_top=20., base_top=17.3, rim_fillet=1.2,
         key_opening=17.2, key_radius=1., key_chamfer=.35,
         shaft_hole_d=8.8, skirt_outer=[65.5,51.5,3.75], skirt_inner=[63.1,49.1,2.55],
         skirt_bottom=15.5, skirt_top=17.65, skirt_clearance_per_side=.25,
         skirt_lead_chamfer=.25, shoulder_outer=[67.4,53.4,4.7], shoulder_bottom=17.3,
         pcb_cushion_uncompressed=.6, pcb_cushion_compressed=.5, pcb_cushion_outer_d=5.,
         screw_x=30., screw_z=22.,
         post_d=6.4, post_top=12., screw_clearance_d=2.4,
         head_counterbore_d=4.6, head_seat_above_local_floor=3.4,
         boss_d=6.2, boss_bottom=14.1, insert_pilot_d=3.2,
         insert_pilot_depth=3.3, insert_lead_chamfer=.2,
         reference_insert_length=3., reference_screw_length_front=12., reference_screw_length_rear=16.,
         status_window=[4.8,1.6,.5], status_window_center_app=[0.,14.05,28.],
         usb_center_app=[0.,13.6,-22.2], usb_rotation_deg=180.,
         usb_throat=[12.,6.,1.2], usb_port_center_app=[0.,15.25,-28.], usb_mouth_chamfer=.6,
         power_switch='G-Switch MK-12C02-G020 / C963206', power_switch_center_app=[23.,13.6,-23.9],
         power_switch_body=[6.6,1.4,2.7], power_switch_actuator=[1.3,1.15,2.], power_switch_travel=1.5,
         power_switch_peg_pitch=3., power_switch_peg_drill_d=.85,
         power_switch_throat=[4.,2.2,.45], power_switch_port_center_app=[23.,14.25,-28.], power_switch_mouth_chamfer=.8,
         power_switch_bridge_width=3.6, power_switch_bridge_bottom=15.35, power_switch_bridge_inside_y=26.,
         tactile_centers_app=[[-20.,13.6,-22.],[-12.,13.6,-22.]], tactile_body=[4.2,2.5,3.2],
         tactile_access_d=1.5, tactile_lead_d=2.1, tactile_lead_depth=.3,
         tactile_guide_outer_d=3.2, tactile_guide_bottom=16.5,
         encoder_recess=[13.3,13.2,18.45], encoder_recess_center=[20.,10.25], lra_raise_from_original=.8,
         battery_support_outline=[42.,32.,1.], battery_support_center_app=[-3.,0.], battery_support_top=3.0, battery_adhesive_thickness=.2,
         lra_support_radius=4.35, lra_support_center_app=[25.,15.], lra_support_top=3.1,
         stl_linear_deflection=.025, stl_angular_deflection_rad=.08,
         browser_linear_deflection=.08, browser_angular_deflection_rad=.13)
T=math.radians(P['tilt_deg']); C=math.cos(T); S=math.sin(T)
# x, z in app coordinates (positive z = front)
KEYS=[(-20.,-10.),(0.,-10.),(-20.,10.),(0.,10.),(20.,10.)]
SCREWS=[(-P['screw_x'],P['screw_z']),(P['screw_x'],P['screw_z']),(-P['screw_x'],-P['screw_z']),(P['screw_x'],-P['screw_z'])]

def rr(w,d,r,h,z=0):
    return cq.Workplane('XY').rect(w,d).extrude(h).edges('|Z').fillet(r).translate((0,0,z))

def cyl(r,h,x,y,z):
    return cq.Workplane('XY').circle(r).extrude(h).translate((x,y,z))

def floor_y(app_z): return math.tan(T)*app_z-1/C

def below_plane(offset_normal=0):
    # Top face is at world height offset_normal; this tool fills the half-space below.
    return cq.Workplane('XY').box(250,250,100,centered=(True,True,False)).translate((0,0,-100)).rotate((0,0,0),(1,0,0),-P['tilt_deg']).translate((0,0,(-1+offset_normal)/C))

class FloorEdges(cq.Selector):
    def filter(self, objects):
        return [o for o in objects if isinstance(o,cq.Edge) and abs(C*o.Center().z+S*o.Center().y+1)<1e-5]

class TopHoleEdges(cq.Selector):
    def filter(self, objects):
        result=[]
        for edge in objects:
            if not isinstance(edge,cq.Edge): continue
            vertices=edge.Vertices()
            if not vertices or not all(abs(v.Z-P['top_top'])<1e-5 for v in vertices): continue
            q=edge.Center()
            near_key=any(math.hypot(q.x-x,q.y+z)<12.4 for x,z in KEYS)
            near_knob=math.hypot(q.x-20,q.y-10)<6
            if near_key or near_knob: result.append(edge)
        return result

def port(w,h,r,x,height):
    return rr(w,h,r,8,-4).translate((x,height,0)).rotate((0,0,0),(1,0,0),90).translate((0,27,0))

def rear_mouth(w,h,r,x,height,chamfer):
    # A true 45-degree rounded entry, measured on the flat outer rear wall at CAD y=28.
    # Extra 0.1 mm outside the wall makes the Boolean robust at the exterior face.
    inner=rr(w,h,r,1).faces('<Z').val().outerWire()
    outer=rr(w+2*(chamfer+.1),h+2*(chamfer+.1),r+chamfer+.1,1).faces('<Z').val().outerWire().translate((0,0,-chamfer-.1))
    solid=cq.Solid.makeLoft([inner,outer],ruled=True)
    return cq.Workplane('XY').newObject([solid]).translate((x,height,0)).rotate((0,0,0),(1,0,0),90).translate((0,28-chamfer,0))

def rear_port_tools():
    result={}
    for prefix in ['usb','power_switch']:
        w,h,r=P[prefix+'_throat']; x,y,_=P[prefix+'_port_center_app']; c=P[prefix+'_mouth_chamfer']
        result[prefix]={'closed':port(w,h,r,x,y),'mouth':rear_mouth(w,h,r,x,y,c),'open':port(w,24,r,x,y-h/2+12)}
    return result

def build():
    print('Building continuous bottom solid...',flush=True)
    outer=rr(P['width'],P['depth'],P['outline_radius'],P['base_top']+5,-5).cut(below_plane())
    outer=outer.edges(FloorEdges()).chamfer(.6)
    cavity=rr(P['width']-2*P['wall'],P['depth']-2*P['wall'],P['outline_radius']-P['wall'],31,-5).cut(below_plane(P['floor']))
    base=outer.cut(cavity)
    # The inner floor is inclined relative to the PCB. Provide a complete planar seat for the LRA foam.
    lx,lz=P['lra_support_center_app']
    support=cyl(P['lra_support_radius'],P['lra_support_top']+5,lx,-lz,-5).intersect(outer)
    base=base.union(support)
    bx,bz=P['battery_support_center_app']
    battery_seat=rr(*P['battery_support_outline'],P['battery_support_top']+5,-5).translate((bx,-bz,0)).intersect(outer)
    base=base.union(battery_seat)
    for x,z in SCREWS:
        post=cyl(P['post_d']/2,P['post_top']+5,x,-z,-5).intersect(outer)
        base=base.union(post)
    for x,z in SCREWS:
        base=base.cut(cyl(P['screw_clearance_d']/2,20,x,-z,-6))
        seat=floor_y(z)+P['head_seat_above_local_floor']
        base=base.cut(cyl(P['head_counterbore_d']/2,seat+7,x,-z,-7))
    ports=rear_port_tools()
    for p in ports.values(): base=base.cut(p['open']).cut(p['mouth'])
    sw=P['status_window']; sx,sy,sz=P['status_window_center_app']
    base=base.cut(port(*sw,sx,sy).translate((0,-27-sz,0))).clean()
    print('Building continuous top solid with R1.2 edge...',flush=True)
    top=rr(P['width'],P['depth'],P['outline_radius'],P['top_top']-P['top_bottom'],P['top_bottom']).edges('>Z').fillet(P['rim_fillet'])
    lip=rr(*P['skirt_outer'],P['skirt_top']-P['skirt_bottom'],P['skirt_bottom']).cut(rr(*P['skirt_inner'],3,P['skirt_bottom']-.3))
    lip=lip.edges('<Z').chamfer(P['skirt_lead_chamfer'])
    top=top.union(lip)
    shoulder=rr(*P['shoulder_outer'],P['skirt_top']-P['shoulder_bottom'],P['shoulder_bottom']).cut(rr(*P['skirt_inner'],1,P['shoulder_bottom']-.2))
    top=top.union(shoulder)
    # A lid-mounted bridge closes the high part of the power-switch installation slot.
    # The base remains open to the seam, so the soldered PCB can lower vertically.
    bridge=cq.Workplane('XY').box(P['power_switch_bridge_width'],2.,P['skirt_top']-P['power_switch_bridge_bottom'],centered=(True,False,False)).translate((P['power_switch_center_app'][0],P['power_switch_bridge_inside_y'],P['power_switch_bridge_bottom']))
    top=top.union(bridge)
    boss_envelope=rr(*P['skirt_outer'],P['top_bottom']-P['boss_bottom']+.3,P['boss_bottom']-.1)
    for x,z in SCREWS:
        boss=cyl(P['boss_d']/2,P['skirt_top']-P['boss_bottom'],x,-z,P['boss_bottom']).intersect(boss_envelope)
        top=top.union(boss)
    for x,z in SCREWS:
        pilot=cyl(P['insert_pilot_d']/2,P['insert_pilot_depth']+.2,x,-z,P['boss_bottom']-.2)
        lead=cq.Solid.makeCone(P['insert_pilot_d']/2+P['insert_lead_chamfer'],P['insert_pilot_d']/2,P['insert_lead_chamfer'],cq.Vector(x,-z,P['boss_bottom']),cq.Vector(0,0,1))
        top=top.cut(pilot.union(cq.Workplane('XY').newObject([lead])))
    for x,z in KEYS:
        top=top.cut(rr(P['key_opening'],P['key_opening'],P['key_radius'],10,13).translate((x,-z,0)))
    top=top.cut(cyl(P['shaft_hole_d']/2,12,20,10,12))
    top=top.edges(TopHoleEdges()).chamfer(P['key_chamfer'])
    er=P['encoder_recess']; ex,ey=P['encoder_recess_center']
    top=top.cut(rr(er[0],er[1],.7,er[2]-13,13).translate((ex,ey,0)))
    for p in ports.values(): top=top.cut(p['closed']).cut(p['mouth'])
    for x,_,z in P['tactile_centers_app']:
        top=top.union(cyl(P['tactile_guide_outer_d']/2,P['top_bottom']+.05-P['tactile_guide_bottom'],x,-z,P['tactile_guide_bottom']))
        top=top.cut(cyl(P['tactile_access_d']/2,5,x,-z,P['tactile_guide_bottom']-.1))
        lead=cq.Solid.makeCone(P['tactile_access_d']/2,P['tactile_lead_d']/2,P['tactile_lead_depth'],cq.Vector(x,-z,P['top_top']-P['tactile_lead_depth']),cq.Vector(0,0,1))
        top=top.cut(cq.Workplane('XY').newObject([lead]))
    top=top.clean()
    return {'base':base,'top':top}

def triangulate(shape, tol=.025, ang=.08):
    vertices, triangles=shape.val().tessellate(tol,ang)
    m=trimesh.Trimesh(vertices=np.array([v.toTuple() for v in vertices]), faces=np.array(triangles),process=True)
    m.merge_vertices(digits_vertex=7)
    m.remove_unreferenced_vertices()
    if m.volume<0: m.invert()
    return m

def app_mesh(mesh):
    result=mesh.copy()
    result.apply_transform(np.array([[1,0,0,0],[0,0,1,0],[0,-1,0,0],[0,0,0,1.]]))
    return result

def print_mesh(mesh, part):
    result=mesh.copy()
    if part=='base':
        result.apply_transform(trimesh.transformations.rotation_matrix(T,[1,0,0]))
    else:
        result.apply_transform(trimesh.transformations.rotation_matrix(math.pi,[1,0,0]))
    result.apply_translation([0,0,-result.bounds[0,2]])
    return result

def stats(shape, mesh):
    return dict(cad_valid=bool(shape.val().isValid()),cad_solids=len(shape.solids().vals()),
                volume_mm3=round(shape.val().Volume(),3),mesh_volume_mm3=round(float(mesh.volume),3),
                watertight=bool(mesh.is_watertight),winding_consistent=bool(mesh.is_winding_consistent),
                surface_components=int(len(mesh.split(only_watertight=False))),
                vertices=len(mesh.vertices),triangles=len(mesh.faces),
                cad_bbox_mm=[round(v,4) for v in (shape.val().BoundingBox().xlen,shape.val().BoundingBox().ylen,shape.val().BoundingBox().zlen)])

def main():
    parts=build(); checks={}; web={'version':'4.0','units':'mm','coordinates':'app local x right, y up, z front. 6-degree product rotation NOT applied.','parameters':P}
    for name,shape in parts.items():
        print('Export',name,flush=True)
        cq.exporters.export(shape,str(OUT/f'{name}-assembly.step'))
        mesh=triangulate(shape)
        checks[name]=stats(shape,mesh)
        if not (checks[name]['cad_valid'] and checks[name]['cad_solids']==1 and checks[name]['watertight'] and checks[name]['winding_consistent'] and checks[name]['surface_components']==1 and checks[name]['volume_mm3']>0):
            raise RuntimeError(f'Geometry validation failed: {name}: {checks[name]}')
        pm=print_mesh(mesh,name)
        pm.export(OUT/f'{name}-print-mm.stl')
        checks[name]['print_bbox_mm']=np.round(pm.extents,4).tolist()
        checks[name]['print_min_z_mm']=round(float(pm.bounds[0,2]),6)
        wv,wf=shape.val().tessellate(P['browser_linear_deflection'],P['browser_angular_deflection_rad'])
        # Preserve BREP face vertex boundaries: flat and curved faces must not share smoothing normals.
        wn=[]
        for face in shape.val().Faces():
            fv,_=face.tessellate(P['browser_linear_deflection'],P['browser_angular_deflection_rad'])
            if face.geomType()=='PLANE': wn.extend([face.normalAt().toTuple()]*len(fv))
            else: wn.extend(face.normalAt(v).toTuple() for v in fv)
        wm=app_mesh(trimesh.Trimesh(vertices=[v.toTuple() for v in wv],faces=wf,process=False))
        normals=np.asarray(wn)
        if len(normals)!=len(wm.vertices): raise RuntimeError('BREP normal/vertex mismatch')
        normals=normals[:,[0,2,1]]*np.array([1,1,-1])
        web[name]={'positions':np.round(wm.vertices,5).ravel().tolist(),'indices':wm.faces.ravel().tolist(),'normals':np.round(normals,6).ravel().tolist()}
    overlap=parts['base'].intersect(parts['top'])
    checks['assembly_intersection_mm3']=round(sum(s.Volume() for s in overlap.solids().vals()),9)
    checks['assembly_intersection_empty']=len(overlap.solids().vals())==0
    if checks['assembly_intersection_mm3']>1e-7: raise RuntimeError('Top and base intersect')
    # Verify board slab fits the cavity and screw locations. Board is concept outline only.
    board=rr(65.6,51.6,3.6,1.6,12.)
    for x,z in SCREWS: board=board.cut(cyl(1.2,3,x,-z,11.5))
    checks['pcb_base_intersection_mm3']=round(sum(s.Volume() for s in board.intersect(parts['base']).solids().vals()),9)
    checks['pcb_top_intersection_mm3']=round(sum(s.Volume() for s in board.intersect(parts['top']).solids().vals()),9)
    # Body envelope of battery and raised LRA, excluding loose wires.
    battery=rr(40,30,1.2,5,3.2).translate((-3,0,0))
    lra=cyl(4.15,.7,25,-15,3.1).union(cyl(4,3.2,25,-15,3.8))
    checks['battery_base_intersection_mm3']=round(sum(s.Volume() for s in battery.intersect(parts['base']).solids().vals()),9)
    checks['lra_base_intersection_mm3']=round(sum(s.Volume() for s in lra.intersect(parts['base']).solids().vals()),9)
    # Conservative component body envelopes are used here, not invented high-fidelity solids.
    # USB extrema are from the project's original GT-USB-7010ANS mesh, rotated 180 degrees.
    ux,uy,uz=P['usb_center_app']
    usb=cq.Workplane('XY').box(8.939784,7.750048,4.169918,centered=(True,False,False)).translate((ux,-uz-2.77495,uy-.899922))
    sx,sy,sz=P['power_switch_center_app']; bw,bh,bd=P['power_switch_body']
    switch_body=cq.Workplane('XY').box(bw,bd,bh,centered=(True,True,False)).translate((sx,-sz,sy))
    aw,ah,ad=P['power_switch_actuator']
    switch_sweep=cq.Workplane('XY').box(aw+P['power_switch_travel'],ad,ah,centered=(True,False,False)).translate((sx,-sz+bd/2,sy))
    tactile=cq.Workplane('XY')
    for tx,ty,tz in P['tactile_centers_app']:
        tw,th,td=P['tactile_body']
        body=cq.Workplane('XY').box(tw,td,th,centered=(True,True,False)).translate((tx,-tz,ty))
        tactile=body if not tactile.vals() else tactile.union(body)
    for cname,component in [('usb_body_envelope',usb),('power_switch_body',switch_body),('power_switch_actuator_full_travel',switch_sweep),('tactile_body_envelopes',tactile)]:
        for pname in ['base','top']:
            volume=sum(s.Volume() for s in component.intersect(parts[pname]).solids().vals())
            checks[f'{cname}_{pname}_intersection_mm3']=round(volume,9)
            if volume>1e-7: raise RuntimeError(f'{cname} intersects {pname}: {volume}')
    # A 1.0 mm straight probe can pass through both guide bores to the button tops.
    for n,(tx,ty,tz) in enumerate(P['tactile_centers_app'],2):
        probe=cyl(.5,P['top_top']+2-(ty+P['tactile_body'][1]),tx,-tz,ty+P['tactile_body'][1])
        checks[f'SW{n}_probe_top_intersection_mm3']=round(sum(s.Volume() for s in probe.intersect(parts['top']).solids().vals()),9)
    checks['tactile_guide_to_button_gap_mm']=round(P['tactile_guide_bottom']-(13.6+P['tactile_body'][1]),5)
    checks['usb_outer_face_setback_mm']=round(28-(-uz+4.975098),6)
    checks['usb_rear_anchor_copper_board_edge_margin_mm']=round(25.8-(-uz+2.38+.9),6)
    checks['power_switch_rear_shell_copper_board_edge_margin_mm']=round(25.8-(-sz+1.135+.93/2),6)
    checks['power_switch_tongue_tip_setback_mm']=round(28-(-sz+bd/2+ad),6)
    checks['power_switch_bridge_side_clearance_mm']=round((P['power_switch_throat'][0]-P['power_switch_bridge_width'])/2,6)
    checks['port_note']='Rear slots in base remain open to rim for vertical board insertion. USB assembled throat 12x6, 0.6 entry chamfer. Power switch descending lid bridge leaves 4x2.2 passage, with 0.2 mm side seams and 0.8 entry chamfer. Cable overmould fit remains to be physically tested.'
    checks['nominal_insert_engagement_mm']={str(z):round(floor_y(z)+3.4+(12 if z>0 else 16)-14.1,3) for z in [22,-22]}
    support_faces=[f for f in parts['base'].val().Faces() if f.geomType()=='PLANE' and abs(f.Center().z-P['lra_support_top'])<1e-6 and math.hypot(f.Center().x-25,f.Center().y+15)<.01]
    battery_support_faces=[f for f in parts['base'].val().Faces() if f.geomType()=='PLANE' and abs(f.Center().z-P['battery_support_top'])<1e-6 and math.hypot(f.Center().x+3,f.Center().y)<.01]
    checks['battery_support_top_face_area_mm2']=round(sum(f.Area() for f in battery_support_faces),6)
    checks['battery_adhesive_gap_mm']=round(3.2-P['battery_support_top'],6)
    checks['lra_to_battery_support_planar_clearance_mm']=round(25-P['lra_support_radius']-(-3+P['battery_support_outline'][0]/2),6)
    checks['lra_support_top_face_area_mm2']=round(sum(f.Area() for f in support_faces),6)
    checks['lra_foam_contact_area_mm2']=round(math.pi*4.15**2,6)
    checks['lra_support_right_front_post_clearance_mm']=round(math.hypot(30-25,22-15)-P['lra_support_radius']-P['post_d']/2,6)
    checks['lra_support_battery_clearance_mm']=round(25-P['lra_support_radius']-17,6)
    checks['encoder_body_recess_clearance_mm']=round(P['encoder_recess'][2]-(13.6+4.500118),5)
    checks['positive_stop']='Top shoulder at local y=17.3 contacts base rim, maintaining the 0.3 mm visible seam under screw load.'
    checks['accuracy_note']='Exact OpenCascade BREP; STL tessellation tolerance 0.025 mm, angular deflection 0.08 rad. Hardware dimensions and fit have not been physically validated.'
    # A cropped rear-left corner pair fits quickly in a small first fit print.
    clip=cq.Workplane('XY').box(17,15,40,centered=(False,False,False)).translate((-37,15,-10))
    for name,shape in parts.items():
        corner=shape.intersect(clip).clean()
        if len(corner.solids().vals())==1:
            cm=triangulate(corner)
            if cm.is_watertight:
                print_mesh(cm,name).export(OUT/f'{name}-corner-fit-mm.stl')
                checks[f'{name}_corner']=stats(corner,cm)
    # A short paired rear-wall coupon checks the actual cable plug mouth and switch bridge.
    rear_clip=cq.Workplane('XY').box(36,9,40,centered=(False,False,False)).translate((-8,20,-10))
    for name,shape in parts.items():
        coupon=shape.intersect(rear_clip).clean(); cm=triangulate(coupon)
        checks[f'{name}_rear_ports_coupon']=stats(coupon,cm)
        if not (coupon.val().isValid() and len(coupon.solids().vals())==1 and cm.is_watertight and cm.is_winding_consistent):
            raise RuntimeError(f'Invalid rear port coupon: {name}')
        print_mesh(cm,name).export(OUT/f'{name}-rear-ports-fit-mm.stl')
    (OUT/'assembly-meshes.json').write_text(json.dumps(web,separators=(',',':')))
    (OUT/'parameters.json').write_text(json.dumps(P,indent=2))
    (OUT/'geometry-checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
    print(json.dumps(checks,ensure_ascii=False,indent=2),flush=True)

if __name__=='__main__': main()
