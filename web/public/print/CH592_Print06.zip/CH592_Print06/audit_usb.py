"""Verify the USB mesh against the entire rounded throat, including corners.

The source VRML triangles are preserved in usb-original-mesh.json. Every
triangle is clipped against the rear wall slab, not filtered by vertex bounds.
The projected clipped polygons must lie inside a convex rounded rectangle.
Signed distance to that convex rectangle is convex; checking all polygon
vertices therefore proves all their edges and interiors fit, up to source mesh
accuracy. It does not infer a cable overmould size or manufacturing tolerance.
"""
from pathlib import Path
import json
import numpy as np

OUT=Path(__file__).resolve().parent

def clip(poly,axis,value,sign):
    result=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        inside_a=sign*(a[axis]-value)>=-1e-12
        inside_b=sign*(b[axis]-value)>=-1e-12
        if inside_a: result.append(a)
        if inside_a!=inside_b:
            result.append(a+(b-a)*((value-a[axis])/(b[axis]-a[axis])))
    return result

def throat_points():
    source=json.loads((OUT/'usb-original-mesh.json').read_text())
    points=[]; triangles=0; clipped_triangles=0
    for shape in source['shapes']:
        raw=np.asarray(shape['positions']).reshape(-1,3)
        # KiCad mesh → CAD, with the declared 180-degree footprint placement.
        vertices=np.column_stack([-raw[:,0],22.2-raw[:,1],13.6+raw[:,2]])
        for face in np.asarray(shape['indices']).reshape(-1,3):
            triangles+=1
            # Two material regions: the full rear wall Y>=26, and the lid's
            # skirt from Y=24.25 at Z>=15.5. Connector feet below the PCB in
            # the inner cavity must not be misclassified as aperture material.
            hit=False
            for ymin,zmin in [(26.,None),(24.25,15.5)]:
                poly=clip(list(vertices[face]),1,ymin,1)
                if poly: poly=clip(poly,1,28.,-1)
                if poly and zmin is not None: poly=clip(poly,2,zmin,1)
                if poly: hit=True; points.extend(poly)
            if hit: clipped_triangles+=1
    return np.unique(np.round(points,9),axis=0),triangles,clipped_triangles

def clearance(points,w,h,r,cy):
    q=np.abs(points[:,[0,2]]-[0,cy])-[w/2-r,h/2-r]
    signed=np.linalg.norm(np.maximum(q,0),axis=1)+np.minimum(np.maximum(q[:,0],q[:,1]),0)-r
    index=int(signed.argmax())
    return dict(throat_mm=[w,h,r],center_height_mm=cy,
                minimum_geometric_clearance_mm=round(float(-signed[index]),9),
                critical_point_cad_mm=points[index].tolist(),
                collision=bool(signed[index]>1e-7))

def audit(parameters=None):
    p,triangles,clipped=throat_points()
    candidates=[(10.2,4.2,1.2,15.25),(9.8,3.8,1.2,15.25),(9.6,3.8,1.2,15.25),(9.6,3.8,1.2,15.28)]
    report=dict(method='clip every original mesh triangle to rear wall CAD Y=26..28 and locator skirt CAD Y=24.25..28, Z>=15.5; analytic convex rounded-rectangle signed distance including R corners',
                input_triangles=triangles,triangles_intersecting_wall_slab=clipped,
                clipped_unique_vertices=len(p),wall_projection_bounds_cad_mm=[p.min(0).tolist(),p.max(0).tolist()],
                candidates=[clearance(p,*candidate) for candidate in candidates],
                source_limit='Original project VRML mesh, not certified connector tolerance; cable overmould, print shrinkage and insertion misalignment require physical coupon.')
    if parameters:
        report['selected']=clearance(p,*parameters['usb_throat'],parameters['usb_port_center_app'][1])
        report['outer_mouth_mm']=[round(parameters['usb_throat'][i]+2*parameters['usb_mouth_chamfer'],6) for i in [0,1]]
    (OUT/'usb-throat-checks.json').write_text(json.dumps(report,indent=2))
    return report

if __name__=='__main__':
    params=json.loads((OUT/'parameters.json').read_text()) if (OUT/'parameters.json').exists() else None
    print(json.dumps(audit(params),indent=2))
