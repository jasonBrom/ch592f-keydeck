"""Exact C49352235 library STEP and manufacturer-limit clearance checks.

Input STEP is the LCSC-owned EDA library model, not advertised as maker STEP.
Dimensions in C49352235_dimensions.json distinguish library and maker limits.
All assembly solids are in CAD millimetres: X=appx, Y=-appz, Z=appy.
"""
from pathlib import Path
import json
import cadquery as cq

OUT=Path(__file__).resolve().parent
KEYS=[(-20.,-10.),(0.,-10.),(-20.,10.),(0.,10.),(20.,10.)]

def rr(w,d,r,h,z=0):
    return cq.Workplane('XY').rect(w,d).extrude(h).edges('|Z').fillet(r).translate((0,0,z))

def intersection(a,b):
    return round(sum(s.Volume() for s in a.intersect(b).solids().vals()),9)

def run(parts=None):
    if parts is None:
        parts={name:cq.importers.importStep(str(OUT/f'{name}-assembly.step')) for name in ['base','top']}
    source=cq.importers.importStep(str(OUT/'CPG151101S11_easyeda.step'))
    battery=rr(40.,30.,1.2,5.,3.2).translate((-3,0,0))
    lra=cq.Workplane('XY').circle(4.15).extrude(.7).translate((25,-15,3.1)).union(cq.Workplane('XY').circle(4.).extrude(3.2).translate((25,-15,3.8)))
    # The viewer adds foil/seal/tape to the body. A deliberately conservative
    # box includes its highest 8.45-mm tape surface and planar outer extremities.
    battery_visual=cq.Workplane('XY').box(42.05,32.,5.25,centered=(True,True,False)).translate((-2.725,0,3.2))
    obstacles={**parts,'battery_body_placeholder':battery,'battery_visual_foil_tape_envelope':battery_visual,'lra_with_foam':lra}
    report=dict(source='C49352235 LCSC official EDA library STEP, nominal, 3 solids; manufacturer drawing is separately used for maximum bounding envelope.',
                cad_mapping='source rotated 180 degrees around X, translated (key_x-0.635, -key_app_z+3.81, 12)',
                declared_limits=dict(pcb_bottom_y=12.,socket_max_below_board=1.95,socket_min_y=10.05,
                battery_body_max_y=8.2,battery_body_vertical_gap=1.85,battery_body_size_mm=[40,30,5],
                battery_visual_tape_max_y=8.45,battery_visual_tape_vertical_gap=1.60),
                exact_library_step={},manufacturer_maximum_envelope={},socket_pairs={})
    sockets=[]
    for number,(x,z) in enumerate(KEYS,4):
        nominal=source.rotate((0,0,0),(1,0,0),180).translate((x-.635,-z+3.81,12))
        # Includes both the larger 14.80 +0.10 drawing view and metal-section
        # 1.85 +0.10 dimension. It excludes intentional boss insertion into PCB.
        maximum=cq.Workplane('XY').box(14.9,5.94,1.95,centered=(True,True,False)).translate((x-.635,-z+3.81,10.05))
        for category,shape in [('exact_library_step',nominal),('manufacturer_maximum_envelope',maximum)]:
            b=shape.val().BoundingBox()
            row={'bbox_cad_mm':[[round(b.xmin,6),round(b.ymin,6),round(b.zmin,6)],[round(b.xmax,6),round(b.ymax,6),round(b.zmax,6)]]}
            for obstacle,part in obstacles.items():
                volume=intersection(shape,part)
                row[obstacle]={'intersection_mm3':volume,'minimum_distance_mm':round(shape.val().distance(part.val()),6)}
                if volume>1e-7: raise RuntimeError(f'SW{number} {category} intersects {obstacle}: {volume}')
            report[category]['SW'+str(number)]=row
        sockets.append(nominal)
    for a in range(len(sockets)):
        for b in range(a+1,len(sockets)):
            report['socket_pairs'][f'SW{a+4}_SW{b+4}']=dict(intersection_mm3=intersection(sockets[a],sockets[b]),minimum_distance_mm=round(sockets[a].val().distance(sockets[b].val()),6))
    report['boundary']='Battery is a 40x30x5 placeholder body, not a purchased-pack/foil/PCM/lead/swell qualification. Loose cables and solder fillets are not provided as authoritative geometry. PCB boss and switch-pin contacts are intentional mating relationships and require the matching PCB drill drawing and real parts.'
    (OUT/'socket-clearance-checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    return report

if __name__=='__main__':
    print(json.dumps(run(),ensure_ascii=False,indent=2))
