"""Package final validated CAD, resin STL, coupons, input sources and reports."""
from pathlib import Path
import json
import zipfile

OUT=Path(__file__).resolve().parent

def main():
    checks=json.loads((OUT/'geometry-checks.json').read_text())
    for name,row in checks.items():
        if isinstance(row,dict) and 'cad_valid' in row:
            assert row['cad_valid'] and row['cad_solids']==1 and row['watertight'] and row['winding_consistent'] and row['surface_components']==1,name
    assert checks['assembly_intersection_mm3']==0
    assert checks['usb_rounded_throat_original_mesh']['selected']['minimum_geometric_clearance_mm']>.3
    assert 'socket_clearance_report' in checks
    filenames=[
        'base-assembly.step','top-assembly.step','selftap-pilot-coupon.step',
        'base-resin-angled-mm.stl','top-resin-angled-mm.stl',
        'base-corner-resin-fit-mm.stl','top-corner-resin-fit-mm.stl',
        'base-rear-ports-resin-fit-mm.stl','top-rear-ports-resin-fit-mm.stl',
        'base-side-buttons-resin-fit-mm.stl','top-side-buttons-resin-fit-mm.stl',
        'selftap-pilot-resin-fit-mm.stl','build_enclosure.py','audit_usb.py',
        'audit_sockets.py','package_print06.py','requirements.txt','README-zh.md',
        'parameters.json','geometry-checks.json','assembly-meshes.json',
        'usb-original-mesh.json','usb-throat-checks.json','socket-clearance-checks.json',
        'CPG151101S11_easyeda.step','C49352235_dimensions.json',
        'SAMZO_28115181DM_datasheet.pdf','CPG151101S11-2_datasheet.pdf',
        'source-PEC11L-4115K-S0020-footprint.json',
        'C2762970-verified-dimensions.json','C963206-verified-dimensions.json']
    for diameter in ['14.0','14.1','14.2']:
        filenames.extend([f'key-locator-{diameter}-fit.step',f'key-locator-{diameter}-resin-fit-mm.stl'])
    missing=[name for name in filenames if not (OUT/name).is_file()]
    if missing: raise FileNotFoundError(missing)
    with zipfile.ZipFile(OUT/'CH592_Print06.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name in filenames: archive.write(OUT/name,'CH592_Print06/'+name)
    print(json.dumps({'archive':'CH592_Print06.zip','files':len(filenames),'bytes':(OUT/'CH592_Print06.zip').stat().st_size},indent=2))

if __name__=='__main__': main()
